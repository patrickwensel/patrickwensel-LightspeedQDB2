﻿using System.Globalization;

namespace QBD2.Services
{
    public class ExcelUploadService
    {
        public async Task ProcessExcelFile(string fileName)
        {

        }
    }

}
